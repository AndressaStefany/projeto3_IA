function vitor()
    Fitfunc= @calcFitness;
    nvars= 2;
    [x, fval]= ga(Fitfunc,nvars)
    
    %{
    var = Populacao([2 2], [0.5 0.5 0.5 0.5], [0 0], 0);
    
    for i = 0:100
        var.avaliaInd();
        fprintf('%f %f \n',var.melhorIndividuo().fitness, var.totalFitness);
        var.melhorIndividuo()
        var.selecao();
        var.atualizaPop();
    end
    %}
    
end