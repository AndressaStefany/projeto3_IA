classdef Populacao < handle
    properties(GetAccess= 'public', SetAccess= 'public')
        individuos=[];
        proximaGe= [];
        objetivo= []
        tamPop= 60;
        taxaElitismo = 0.3;
        taxaMutacao = 0.001;
        totalFitness= 0;
        inv_totalFitness= 0;
    end
    methods(Access= 'public')
        function obj= Populacao(objetivo, range, pos_robo, ang_robo)
            obj.objetivo= objetivo;
            %[front left back right]
            lar= range(2)+range(4);
            alt= range(1)+range(3);
            for i= 1:obj.tamPop
                x_2= rand()*lar-range(4);
                x_1= rand()*alt-range(3);
                x1= x_1*cos(ang_robo)-x_2*sin(ang_robo);
                x2= x_1*sin(ang_robo)+x_2*cos(ang_robo);
                obj.individuos{i}= Individuo(x1+pos_robo(1), x2+pos_robo(2));
            end
        end

        function avaliaInd(obj)
            for i = 1:length(obj.individuos)
                fit = obj.individuos{i}.calcFitness(obj.objetivo);
                obj.totalFitness = obj.totalFitness + fit;
                obj.inv_totalFitness = obj.inv_totalFitness + 1/fit;
            end
            [~, ind]= sort(cellfun(@(x)x.fitness,obj.individuos));
            obj.individuos= obj.individuos(ind);
        end
        
        function y = melhorIndividuo(obj)
            y = obj.individuos{1};
        end
        
        function elitismo(obj)
            numFortes = obj.tamPop*obj.taxaElitismo;
            
            for i=1:numFortes
                obj.proximaGe{end+1} = obj.individuos{i};
            end                
        end
        
        function y = parcialTorneio(obj)
            indUm = randi(obj.tamPop);
            indDois = randi(obj.tamPop);
            
            if indUm < indDois
                y = indUm;
            else
                y = indDois;
            end
        end
        
        function selecao(obj)
            obj.elitismo();
            
            while length(obj.proximaGe) < obj.tamPop
                indUm = obj.parcialTorneio();
                indDois = obj.parcialTorneio();
                
                filho =  Individuo.cruza(obj.individuos{indUm}, obj.individuos{indDois});
                probMutacao = rand();
                
                if probMutacao < obj.taxaMutacao
                    filho.x1 = randi(100);
                    filho.x2 = randi(100);
                end
                
                obj.proximaGe{end+1} = filho;
            end
        end
        
        function atualizaPop(obj)
            obj.inv_totalFitness = 0;
            obj.totalFitness = 0;
            
            obj.individuos = obj.proximaGe;
            obj.proximaGe = {};
        end
   
    end
end