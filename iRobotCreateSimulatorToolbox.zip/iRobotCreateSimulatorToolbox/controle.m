function controleRobo = Controle(robo)
    t = 0.1;
    refPos = [-4.534 -4.541];
    refAngulo = [0];
    % [-2.605 -2.415] [-2.119 0.628] [0.229 0.837] [1.565 2.480] [3.306 2.689] 
    parcObj= { [-4.534 -4.541] [4.440 4.477] };
    cont= 1;
    fim= 1;
    
    while(fim)
        
        [posAtual, posAngulo] = robo.getPosition();

        deltaL = sqrt(sum((refPos - posAtual).^2));
        
        deltaTeta = atan2( refPos(2)-posAtual(2), refPos(1)-posAtual(1) ) - posAngulo;
        deltaTeta = atan2( sin(deltaTeta), cos(deltaTeta) );
        
        deltaL= deltaL*cos(deltaTeta);
        
        velLin = (deltaL/t)/20;
        velAn = (deltaTeta/t)/20;
        
        scatter(refPos(1), refPos(2));
        
        if abs(deltaL) < 0.1
            if cont <= length(parcObj)
                pop = Populacao(parcObj{cont}, genSonar(robo)/4, posAtual, posAngulo);
                %{
                for i = 1:length(pop.individuos)
                    scatter(pop.individuos{i}.x1, pop.individuos{i}.x2);
                end
                %}
                if sqrt(sum((parcObj{cont} - posAtual).^2)) < 0.1
                    cont= cont+1;
                end
                for i = 0:30
                    pop.avaliaInd();
                    pop.selecao();
                    pop.atualizaPop();
                end
                fprintf('%f %f\n', pop.melhorIndividuo().x1, pop.melhorIndividuo().x2);
                refPos = [pop.melhorIndividuo().x1 pop.melhorIndividuo().x2];

                velLin= 0;
            else
                fim= 0;
            end
            %velAn= ((refAngulo-posAngulo)/t)/10;
        end
        %velLin=0;
        %velAn=0;
        SetFwdVelAngVelCreate(robo,velLin,velAn);
        
        fprintf('%f %f %f %f %f %f %f\n', posAtual, refPos, posAngulo, deltaTeta, deltaL)
        
        pause(t)
    end
    controleRobo = 3
end
