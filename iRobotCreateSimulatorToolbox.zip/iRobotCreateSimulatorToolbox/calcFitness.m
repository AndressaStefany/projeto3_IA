function y = calcFitness(x)
    y = sqrt( (5-x(1))^2 + (3-x(2))^2 );
end
