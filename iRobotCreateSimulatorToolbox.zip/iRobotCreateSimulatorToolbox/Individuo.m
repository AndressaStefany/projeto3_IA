classdef Individuo < handle
    properties(GetAccess= 'public', SetAccess= 'public')
        x1= 0;
        x2= 0;
        fitness= 0;
    end
    methods(Access= 'public')
        function obj = Individuo(x1, x2)
            obj.x1 = x1;
            obj.x2 = x2;
        end
        function y = fit(obj)
            y = obj.fitness;
        end
        function y = calcFitness(obj, objetivo)
            obj.fitness = sqrt((obj.x1 - objetivo(1))^2 + (obj.x2 - objetivo(2))^2);
            y = obj.fitness;
        end
    end
    methods(Static, Access = 'public')
        function ind = cruza(obj1, obj2)
            ind = Individuo((obj1.x1+obj2.x1)/2.0, (obj1.x2+obj2.x2)/2.0);
        end
    end
end